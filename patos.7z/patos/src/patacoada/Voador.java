package patacoada;

public interface Voador {
	public void voar();
}
