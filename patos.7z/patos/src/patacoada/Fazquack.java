package patacoada;

public interface Fazquack {
	public void quack();
}
