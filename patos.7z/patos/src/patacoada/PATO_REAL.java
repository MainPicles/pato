package patacoada;

public class PATO_REAL extends Patozo implements Voador, Fazquack{
	
	public PATO_REAL() {}
		
	public void display() {
		System.out.println("Pato real!");
	}
	public void voar() {
		System.out.println("Estou voando");
	}
	
	public void quack() {
		System.out.println("Quack quack quack");
	}
}

