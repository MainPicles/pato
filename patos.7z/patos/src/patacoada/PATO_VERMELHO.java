package patacoada;

public class PATO_VERMELHO extends Patozo implements Voador, Fazquack{
	public PATO_VERMELHO() {}
		
	public void display() {
		System.out.println("Pato vermelho");
	}
	
	public void voar() {
		System.out.println("Estou voando");
	}
	
	public void quack() {
		System.out.println("Quack quack quack");
	}
}
