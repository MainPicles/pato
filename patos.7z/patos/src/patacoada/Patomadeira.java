package patacoada;

public class Patomadeira extends Patozo{
	public Patomadeira() {}
		
	public void display() {
		System.out.println("Pato Madeira");
	}

	public void quack() {}
		//N quacka
	public void Swin() {}
		
	
	public void Voar() {}
	
}
		
