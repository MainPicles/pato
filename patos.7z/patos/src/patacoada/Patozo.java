package patacoada;

public class Patozo {

	public Patozo() {
		// TODO Auto-generated constructor stub
	}
	
	public void quack() {
		System.out.println("Quack!");
	}
	
	public void display() {
		System.out.println("Pato, pato, pato");
	}
	
	public void Swin() {
		System.out.println("Nadando");
	}
	
	public void Voar() {
		System.out.println("Voando");
	}
	
	
}
