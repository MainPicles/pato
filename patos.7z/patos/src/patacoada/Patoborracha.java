package patacoada;

public class Patoborracha extends Patozo{
	public Patoborracha() {}
	
	public void display () {
		System.out.println("Pato Borracha");
	}
	
	public void quack() {
		System.out.println("Quick!");
	}
	
	public void Swin() {
		System.out.println("Boiando..");
	}
	
	public void voar() {
		//cai
	}
}
