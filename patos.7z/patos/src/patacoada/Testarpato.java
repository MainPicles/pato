package patacoada;

public class Testarpato {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Patozo patolino = new Patozo();
		
		patolino.display();
		patolino.quack();
		patolino.Swin();
		patolino.Voar();
		
		
		System.out.println("-----------------------------");
		Patozo patodonaldo = new PATO_REAL();
		patodonaldo.display();
		patodonaldo.quack();
		patodonaldo.Swin();
		patodonaldo.Voar();
		
		System.out.println("-----------------------------");
		Patozo tiopato = new PATO_VERMELHO();
		tiopato.display();
		tiopato.quack();
		tiopato.Swin();
		tiopato.Voar();
		
		System.out.println("-----------------------------");
		Patozo Carlos = new Patoborracha();
		Carlos.display();
		Carlos.quack();
		Carlos.Swin();
		
		System.out.println("-----------------------------");
		Patozo Pedromemes = new Patomadeira();
		Pedromemes.display();
		Pedromemes.quack();
		Pedromemes.Swin();
	}

}
